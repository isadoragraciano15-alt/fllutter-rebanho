package com.example.rebanho

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
