# 🐑 Rebanho Hive - Gerenciamento de Ovelhas

Este projeto foi desenvolvido como um desafio EAD para construir um aplicativo Flutter que utiliza o banco de dados local **Hive** para persistência de dados.

O objetivo principal é gerenciar um rebanho de ovelhas, permitindo a inclusão e edição de registros com uma lista que se atualiza de forma reativa e ordenada.

---

## 🚀 Como Rodar o Projeto

1.  **Pré-requisitos:**
    * Flutter SDK (versão compatível com Dart >=3.0.0)
    * Visual Studio Code (ou outra IDE de sua preferência)
    * Um emulador ou dispositivo (Android/iOS) configurado.

2.  **Instalação de Dependências:**
    Na raiz do projeto, execute o comando para baixar o Hive e as demais dependências:
    ```bash
    flutter pub get
    ```

3.  **Execução:**
    Inicie o emulador/dispositivo e execute o aplicativo:
    ```bash
    flutter run
    ```
    *(Recomenda-se ativar o "Modo Desenvolvedor" do Windows para suporte completo a plugins, se ainda não o fez.)*

---

## 💾 Estrutura e Tecnologias

O projeto está organizado em camadas para melhor manutenibilidade, conforme boas práticas de desenvolvimento:

| Pasta/Arquivo | Responsabilidade Principal |
| :--- | :--- |
| `lib/model/ovelha.dart` | Contém a classe `Ovelha` e o **Adapter Manual** (`OvelhaAdapter`). |
| `lib/data/` | Camada de acesso direto aos dados (Hive Box). |
| `lib/repository/` | Aplica a lógica de negócios, como a **ordenação por RFID** e o acesso reativo. |
| `lib/screens/` | Contém as telas (`OvelhasListScreen` e `OvelhasFormScreen`). |
| `lib/utils/` | Contém classes auxiliares, como o **`RfidInputFormatter`**. |
| `lib/main.dart` | Ponto de entrada: inicializa o Hive e registra o Adapter. |

## ✅ Requisitos do Desafio Cumpridos

Os seguintes requisitos obrigatórios foram implementados:

| Categoria | Requisito Implementado | Ponto Chave no Código |
| :--- | :--- | :--- |
| **Persistência (Hive)** | **Adapter Manual (TypeAdapter):** Não utiliza `build_runner`. | Implementado em `lib/model/ovelha.dart`. |
| **Persistência (Hive)** | **Upsert:** Inclusão e Edição usam a chave `rfidOvelha` (String). | `repository/ovelha_repository.dart` e `data/ovelha_datasource.dart`. |
| **Listagem (UI)** | **Lista Reativa:** Atualização automática da lista. | Utiliza `ValueListenableBuilder` em `screens/ovelhas_list_screen.dart`. |
| **Listagem (UI)** | **Lista Ordenada:** Ovelhas exibidas em ordem crescente por RFID. | Lógica de `sort()` em `repository/ovelha_repository.dart`. |
| **Formulário** | **Máscara RFID Customizada (2.0 pts):** `999-000000000000`. | Implementado em `lib/utils/rfid_formatter.dart` (não foi usado pacote externo). |
| **Formulário** | **Raças Exclusivas (1.0 pt):** Seleção de `Santa Inês`, `Dorper` ou `Texel`. | Lógica de `CheckboxListTile` exclusivo em `screens/ovelhas_form_screen.dart`. |
| **Navegação** | **Fluxo Salvar:** `push` para formulário e `pop(true)` para a lista. | `screens/ovelhas_list_screen.dart` e `screens/ovelhas_form_screen.dart`. |
| **Funcionalidade** | **Fechar App:** Botão fixo no rodapé. | Utiliza `SystemNavigator.pop()` em `screens/ovelhas_list_screen.dart`. |
| **Restrições** | **Atenção aos Requisitos:** Não possui exclusão, favoritos ou data de vacinação. | Verificado em todo o código. |