import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // Para SystemNavigator.pop()
import 'package:hive_flutter/hive_flutter.dart';

import '../main.dart';
import '../model/ovelha.dart';
import '../repository/ovelha_repository.dart';
import 'ovelhas_form_screen.dart';

class OvelhasListScreen extends StatefulWidget {
  const OvelhasListScreen({super.key});

  @override
  State<OvelhasListScreen> createState() => _OvelhasListScreenState();
}

class _OvelhasListScreenState extends State<OvelhasListScreen> {
  final _repository = OvelhaRepository();

  // Função para navegar para o formulário (para Inclusão ou Edição)
  void _navigateToForm({Ovelha? ovelha}) async {
    // Requisito 7: Navegação push
    final shouldUpdate = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => OvelhasFormScreen(ovelhaParaEdicao: ovelha),
      ),
    );

    // O pop do formulário retorna 'true' se o registro foi salvo.
    // O setState abaixo não é estritamente necessário se ValueListenableBuilder for usado
    // corretamente, mas garante que a tela seja notificada sobre o retorno.
    if (shouldUpdate == true) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Rebanho Hive 🐑'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
      ),
      
      // 🔑 Requisito 3 e 4: Listagem REATIVA e ORDENADA (2,0 + 1,0 Pontos)
      // O ValueListenableBuilder escuta as mudanças na 'ovelhasBox'
      body: ValueListenableBuilder<Box<Ovelha>>(
        valueListenable: _repository.getOvelhasListenable(),
        builder: (context, box, child) {
          // Obtém a lista e a ORDENA por RFID, conforme a lógica no Repository
          final ovelhasOrdenadas = _repository.getOvelhasSorted(box);

          if (ovelhasOrdenadas.isEmpty) {
            return const Center(
              child: Text('Nenhuma ovelha cadastrada. Adicione uma!'),
            );
          }

          // Constrói a lista visualmente
          return ListView.builder(
            itemCount: ovelhasOrdenadas.length,
            itemBuilder: (context, index) {
              final ovelha = ovelhasOrdenadas[index];
              return Card(
                elevation: 2,
                margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                child: ListTile(
                  title: Text(ovelha.racaOvelha, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(
                    'RFID: ${ovelha.rfidOvelha} | Idade: ${ovelha.idadeOvelha} anos'
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Ícone de Vacinada
                      Icon(
                        ovelha.indVacinada ? Icons.check_circle : Icons.warning_amber,
                        color: ovelha.indVacinada ? Colors.green : Colors.orange,
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      // Ação para EDITAR (Requisito 3)
                      IconButton(
                        icon: const Icon(Icons.edit, color: Colors.blue),
                        onPressed: () => _navigateToForm(ovelha: ovelha),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),

      // Botão Flutuante para ADICIONAR (Requisito 2)
      floatingActionButton: FloatingActionButton(
        onPressed: () => _navigateToForm(),
        backgroundColor: Theme.of(context).colorScheme.secondary,
        foregroundColor: Colors.white,
        child: const Icon(Icons.add),
      ),

      // 🛑 Requisito 8: Botão FIXO no rodapé para fechar o app (0,3 Pontos)
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(8.0),
        child: ElevatedButton(
          onPressed: () {
            // Usa o SystemNavigator.pop() para fechar o app nativamente
            SystemNavigator.pop(); 
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.red,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 15),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
          child: const Text('Fechar Aplicativo', style: TextStyle(fontSize: 16)),
        ),
      ),
    );
  }
}