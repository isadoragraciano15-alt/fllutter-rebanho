import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../model/ovelha.dart';
import '../repository/ovelha_repository.dart';
import '../utils/rfid_formatter.dart';

// Raças permitidas (Santa Inês, Dorper, Texel)
const List<String> RACAS = ['Santa Inês', 'Dorper', 'Texel'];

class OvelhasFormScreen extends StatefulWidget {
  // Recebe uma ovelha opcional para modo de Edição (Requisito 3)
  final Ovelha? ovelhaParaEdicao; 

  const OvelhasFormScreen({super.key, this.ovelhaParaEdicao});

  @override
  State<OvelhasFormScreen> createState() => _OvelhasFormScreenState();
}

class _OvelhasFormScreenState extends State<OvelhasFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _repository = OvelhaRepository();
  
  // Controllers para os campos de texto
  final _rfidController = TextEditingController();
  final _idadeController = TextEditingController();

  // Variáveis de estado
  String? _racaSelecionada;
  bool _indVacinada = false;

  @override
  void initState() {
    super.initState();
    // 💡 Preenche os campos se for Edição (Requisito 3)
    if (widget.ovelhaParaEdicao != null) {
      final ovelha = widget.ovelhaParaEdicao!;
      _rfidController.text = ovelha.rfidOvelha;
      _idadeController.text = ovelha.idadeOvelha.toString();
      _racaSelecionada = ovelha.racaOvelha;
      _indVacinada = ovelha.indVacinada;
    }
  }

  @override
  void dispose() {
    _rfidController.dispose();
    _idadeController.dispose();
    super.dispose();
  }

  Future<void> _salvarOvelha() async {
    // Validação extra para a raça, que não é um TextFormField
    if (_racaSelecionada == null || !_formKey.currentState!.validate()) {
      return; 
    }
    
    // Cria o objeto Ovelha com os dados do formulário
    final novaOvelha = Ovelha(
      rfidOvelha: _rfidController.text,
      racaOvelha: _racaSelecionada!,
      idadeOvelha: int.parse(_idadeController.text),
      indVacinada: _indVacinada,
    );

    // Requisito 3 e 7: Salva/Atualiza (Upsert) usando o RFID como chave
    await _repository.saveOvelha(novaOvelha);
    
    // Requisito 7: Navegação pop após salvar
    if (mounted) {
      Navigator.pop(context, true); // Retorna 'true' para indicar sucesso
    }
  }

  @override
  Widget build(BuildContext context) {
    bool isEditing = widget.ovelhaParaEdicao != null;

    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? 'Editar Ovelha' : 'Adicionar Ovelha'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              // 1. CAMPO RFID (2,0 PONTOS)
              TextFormField(
                controller: _rfidController,
                keyboardType: TextInputType.number,
                enabled: !isEditing, // RFID não pode ser alterado na edição
                decoration: InputDecoration(
                  labelText: 'RFID da Ovelha (999-000000000000)',
                  hintText: 'Ex: 123-456789012345678',
                  border: const OutlineInputBorder(),
                  suffixIcon: isEditing ? const Icon(Icons.lock) : null, 
                ),
                // 🔑 Requisito 5: TextInputFormatter PRÓPRIO
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly, 
                  RfidInputFormatter(), // Aplica a máscara 999-000000000000
                ],
                // Requisito 5: Validação de comprimento do RFID
                validator: (value) {
                  final numericOnly = value?.replaceAll(RegExp(r'[^\d]'), '');
                  if (numericOnly == null || numericOnly.length != 18) {
                    return 'O RFID deve ter 18 dígitos (999-000000000000).';
                  }
                  return null;
                },
              ),
              
              const SizedBox(height: 20),

              // 2. CAMPO IDADE (Requisito 5: Validação de número inteiro)
              TextFormField(
                controller: _idadeController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Idade (anos)',
                  border: OutlineInputBorder(),
                ),
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly, 
                ],
                validator: (value) {
                  final idade = int.tryParse(value ?? '');
                  if (idade == null || idade < 0) {
                    return 'A idade deve ser um número inteiro maior ou igual a zero.';
                  }
                  return null;
                },
              ),

              const SizedBox(height: 20),

              // 3. CAMPO IND VACINADA
              SwitchListTile(
                title: const Text('Ovelha Vacinada'),
                value: _indVacinada,
                onChanged: (bool value) {
                  setState(() {
                    _indVacinada = value;
                  });
                },
              ),

              const Divider(),
              const Text('Raça da Ovelha (Seleção Exclusiva):', style: TextStyle(fontWeight: FontWeight.bold)),
              
              // 4. CAMPO RAÇAS (CheckBoxListTile Exclusivos) (1,0 PONTO)
              ...RACAS.map((raca) {
                return CheckboxListTile(
                  title: Text(raca),
                  value: _racaSelecionada == raca, // Marcado se for a raca selecionada
                  onChanged: (bool? checked) {
                    setState(() {
                      // 🔑 Requisito 6: Lógica de exclusividade (marcou uma, desmarca as outras)
                      _racaSelecionada = checked! ? raca : null;
                    });
                  },
                );
              }).toList(),

              // Mensagem de erro para a raça (se não for selecionada)
              if (_racaSelecionada == null)
                const Padding(
                  padding: EdgeInsets.only(left: 15.0, bottom: 10),
                  child: Text(
                    'Por favor, selecione a raça da ovelha.',
                    style: TextStyle(color: Colors.red, fontSize: 12),
                  ),
                ),

              const SizedBox(height: 30),

              // BOTÃO SALVAR
              ElevatedButton.icon(
                onPressed: _racaSelecionada != null ? _salvarOvelha : null,
                icon: const Icon(Icons.save),
                label: const Text('Salvar Ovelha', style: TextStyle(fontSize: 18)),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}