import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'model/ovelha.dart'; // Importa a classe Ovelha e o OvelhaAdapter
import 'screens/ovelhas_list_screen.dart'; // Importa a tela inicial

// 🔑 Constante para o nome da Box (usada no DataSource)
const String OVELHAS_BOX = 'ovelhasBox'; 

void main() async {
  // Garante que os bindings do Flutter estejam prontos para a inicialização assíncrona
  WidgetsFlutterBinding.ensureInitialized();
  
  // 1. Inicializa o Hive
  await Hive.initFlutter(); 
  
  // 2. Registra o Adapter MANUAL (Obrigatório)
  // O Hive precisa saber como salvar e ler o objeto Ovelha
  Hive.registerAdapter(OvelhaAdapter()); 
  
  // 3. Abre a Box onde as ovelhas serão armazenadas
  // Abrimos a Box usando o tipo <Ovelha>
  await Hive.openBox<Ovelha>(OVELHAS_BOX); 

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Rebanho Hive',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        // Tema principal verde, com cores de destaque adequadas
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.green, 
          primary: Colors.green, // Define a cor primária para a AppBar
        ), 
        useMaterial3: true,
      ),
      // A primeira tela do app é a tela de listagem
      home: const OvelhasListScreen(), 
    );
  }
}