import 'package:hive/hive.dart';

// O TypeId deve ser um número único (0 a 223) para esta classe.
const int OVELHA_TYPE_ID = 0;

class Ovelha {
  // Atributos do modelo, conforme o desafio
  final String rfidOvelha; 
  final String racaOvelha; // Santa Inês, Dorper, Texel
  final int idadeOvelha; 
  final bool indVacinada;

  Ovelha({
    required this.rfidOvelha,
    required this.racaOvelha,
    required this.idadeOvelha,
    required this.indVacinada,
  });
}

// ⭐️ IMPLEMENTAÇÃO MANUAL DO TYPE ADAPTER ⭐️
// Esta classe é OBRIGATÓRIA para ensinar o Hive como serializar (escrever) e
// desserializar (ler) um objeto Ovelha, sem usar o build_runner.
class OvelhaAdapter extends TypeAdapter<Ovelha> {
  // Define o TypeId que será usado para o registro no main.dart
  @override
  final int typeId = OVELHA_TYPE_ID; 

  // Método que ensina o Hive a LER (read) o objeto da memória binária
  @override
  Ovelha read(BinaryReader reader) {
    // 1. Lê a quantidade de campos escritos
    final numOfFields = reader.readByte();
    
    // 2. Cria um mapa para armazenar os campos (Field ID: Valor)
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    
    // 3. Retorna o objeto Ovelha, usando os IDs dos campos para buscar os valores
    return Ovelha(
      rfidOvelha: fields[0] as String,  // Campo com ID 0
      racaOvelha: fields[1] as String,  // Campo com ID 1
      idadeOvelha: fields[2] as int,    // Campo com ID 2
      indVacinada: fields[3] as bool,   // Campo com ID 3
    );
  }

  // Método que ensina o Hive a ESCREVER (write) o objeto para a memória binária
  @override
  void write(BinaryWriter writer, Ovelha obj) {
    // 1. Escreve a quantidade de campos (4)
    writer.writeByte(4); 
    
    // 2. Escreve cada campo na ordem: (ID do campo, Valor do campo)
    writer
      ..writeByte(0)
      ..write(obj.rfidOvelha)
      ..writeByte(1)
      ..write(obj.racaOvelha)
      ..writeByte(2)
      ..write(obj.idadeOvelha)
      ..writeByte(3)
      ..write(obj.indVacinada);
  }
}