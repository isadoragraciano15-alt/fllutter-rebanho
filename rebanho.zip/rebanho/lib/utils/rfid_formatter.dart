import 'package:flutter/services.dart';

class RfidInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final text = newValue.text;
    
    // Remove caracteres não-numéricos
    final numericOnly = text.replaceAll(RegExp(r'[^\d]'), '');
    
    // Máscara completa: 3 dígitos + hífen + 15 dígitos = 19 caracteres (excluíndo o hífen)
    const int maxLen = 18; // 3 + 15 = 18 dígitos no total
    
    // Limita o comprimento total dos números
    if (numericOnly.length > maxLen) {
      return oldValue;
    }
    
    final buffer = StringBuffer();
    
    // 1. Adiciona os 3 primeiros dígitos
    for (int i = 0; i < numericOnly.length; i++) {
      buffer.write(numericOnly[i]);
      
      // 2. Insere o hífen APÓS o 3º dígito
      if (i == 2 && i != numericOnly.length - 1) {
        buffer.write('-');
      }
    }
    
    final finalText = buffer.toString();
    
    // Calcula a nova posição do cursor
    int selectionIndex = finalText.length;
    
    // Retorna o novo valor com a máscara aplicada
    return TextEditingValue(
      text: finalText,
      selection: TextSelection.collapsed(offset: selectionIndex),
    );
  }
}