import '../data/ovelha_datasource.dart';
import '../model/ovelha.dart';
import 'package:hive/hive.dart';
import 'package:flutter/foundation.dart'; // Necessário para ValueListenable

class OvelhaRepository {
  final OvelhaDataSource _dataSource = OvelhaDataSource();

  // Função que salva/atualiza uma ovelha, delegando para o DataSource.
  Future<void> saveOvelha(Ovelha ovelha) => _dataSource.save(ovelha);

  // 🔑 Requisito 3 e 4: Obtém o ValueListenable para listagem REATIVA.
  // A UI (ValueListenableBuilder) vai ouvir esta Box e se atualizar automaticamente.
  ValueListenable<Box<Ovelha>> getOvelhasListenable() {
    return _dataSource.box.listenable();
  }

  // 🔑 Requisito 4: Lógica de Negócio para obter a lista ORDENADA.
  // Esta função deve ser chamada dentro do ValueListenableBuilder na tela.
  List<Ovelha> getOvelhasSorted(Box<Ovelha> box) {
    // 1. Pega todos os valores da Box
    final ovelhas = box.values.toList();
    
    // 2. Ordena a lista pelo campo rfidOvelha (String), que é a chave.
    // Assim, a lista é exibida em ordem crescente de RFID.
    ovelhas.sort((a, b) => a.rfidOvelha.compareTo(b.rfidOvelha)); 
    
    return ovelhas;
  }

  // Função auxiliar para buscar uma ovelha específica (usada na edição)
  Ovelha? getOvelhaByRfid(String rfid) {
    // O .get(key) do Hive é muito rápido
    return _dataSource.box.get(rfid);
  }
}