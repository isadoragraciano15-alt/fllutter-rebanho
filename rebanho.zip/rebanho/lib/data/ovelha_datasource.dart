import 'package:hive/hive.dart';
import '../model/ovelha.dart';
import '../main.dart'; // Importa a constante OVELHAS_BOX

class OvelhaDataSource {
  // A Box já foi aberta no main.dart, apenas a acessamos
  // Nota: O Hive.box() é síncrono, pois o await Hive.openBox() já foi feito.
  final Box<Ovelha> _box = Hive.box<Ovelha>(OVELHAS_BOX);

  // Função para CRIAR ou ATUALIZAR (UPSERT) uma ovelha.
  // Requisito: Usar a chave (key) como o rfidOvelha.
  Future<void> save(Ovelha ovelha) async {
    // O .put() do Hive verifica se a 'key' (rfidOvelha) já existe.
    // Se existir, ele ATUALIZA o valor. Se não existir, ele INCLUI.
    await _box.put(ovelha.rfidOvelha, ovelha);
  }

  // Retorna a Box (para ser usada na camada Repository para listagem reativa)
  Box<Ovelha> get box => _box;
}